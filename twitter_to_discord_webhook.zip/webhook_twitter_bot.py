import requests
import time
import os

WEBHOOK_URL = os.getenv("WEBHOOK_URL")
TWITTER_BEARER_TOKEN = os.getenv("TWITTER_BEARER_TOKEN")
TWITTER_USERNAME = os.getenv("TWITTER_USERNAME")

headers = {
    "Authorization": f"Bearer {TWITTER_BEARER_TOKEN}"
}

latest_tweet_id = None

def get_user_id(username):
    url = f"https://api.twitter.com/2/users/by/username/{username}"
    response = requests.get(url, headers=headers)
    if response.status_code == 200:
        return response.json()["data"]["id"]
    else:
        print("유저 ID 가져오기 실패:", response.text)
        return None

def fetch_latest_tweet(user_id):
    url = f"https://api.twitter.com/2/users/{user_id}/tweets?exclude=replies,retweets&max_results=5"
    response = requests.get(url, headers=headers)
    if response.status_code == 200:
        tweets = response.json().get("data", [])
        return tweets[0] if tweets else None
    else:
        print("트윗 불러오기 실패:", response.text)
        return None

def send_to_discord(text, tweet_url):
    data = {
        "content": f"{tweet_url}\n\n{text}"
    }
    response = requests.post(WEBHOOK_URL, json=data)
    if response.status_code != 204:
        print("웹훅 전송 실패:", response.text)

def main():
    global latest_tweet_id
    user_id = get_user_id(TWITTER_USERNAME)
    if not user_id:
        return

    while True:
        tweet = fetch_latest_tweet(user_id)
        if tweet and tweet["id"] != latest_tweet_id:
            latest_tweet_id = tweet["id"]
            tweet_url = f"https://twitter.com/{TWITTER_USERNAME}/status/{tweet['id']}"
            send_to_discord(tweet["text"], tweet_url)
        time.sleep(60)

if __name__ == "__main__":
    main()