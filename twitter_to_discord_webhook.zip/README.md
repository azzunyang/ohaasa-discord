# Twitter to Discord Webhook Bot

This script checks a Twitter user's timeline every minute and sends new tweets to a Discord webhook.

## Environment Variables

- `WEBHOOK_URL`: Discord webhook URL
- `TWITTER_BEARER_TOKEN`: Twitter API Bearer Token
- `TWITTER_USERNAME`: Twitter username (e.g., Hi_Ohaasa)